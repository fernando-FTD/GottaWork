<?php
$hash = password_hash('rizqi123', PASSWORD_DEFAULT);
echo $hash;
?>